create definer = root@`%` event delete_request on schedule
    every '1' DAY
        starts '2024-06-14 16:46:33'
    on completion preserve
    enable
    do
    BEGIN

delete from t_report_requestrecord WHERE reportType IN(
'GET_FBA_FULFILLMENT_LONGTERM_STORAGE_FEE_CHARGES_DATA',
'GET_FBA_FULFILLMENT_INVENTORY_HEALTH_DATA',
'GET_FBA_INVENTORY_PLANNING_DATA',
'GET_FBA_REIMBURSEMENTS_DATA',
'GET_FBA_STORAGE_FEE_CHARGES_DATA'
)
 AND  lastupdate<DATE_SUB(NOW(),INTERVAL 30 DAY);

delete from t_report_requestrecord WHERE reportType='GET_V2_SETTLEMENT_REPORT_DATA_FLAT_FILE_V2' AND  lastupdate<DATE_SUB(NOW(),INTERVAL 365 DAY);

delete from t_report_requestrecord WHERE reportType NOT  IN(
'GET_FBA_FULFILLMENT_LONGTERM_STORAGE_FEE_CHARGES_DATA',
'GET_FBA_FULFILLMENT_INVENTORY_HEALTH_DATA',
'GET_FBA_INVENTORY_PLANNING_DATA',
'GET_FBA_REIMBURSEMENTS_DATA',
'GET_FBA_STORAGE_FEE_CHARGES_DATA',
'GET_V2_SETTLEMENT_REPORT_DATA_FLAT_FILE_V2'
)
 AND  lastupdate<DATE_SUB(NOW(),INTERVAL 3 DAY);
 

update t_product_info  i
LEFT JOIN t_amazon_auth a ON a.id=i.amazonAuthId
LEFT JOIN t_product_in_opt o ON o.pid=i.id
LEFT JOIN db_erp.t_erp_material m ON m.sku=IFNULL(o.msku,i.sku) AND m.shopid=a.shop_id AND m.isDelete=0
SET o.`owner`=m.`owner`
WHERE o.`owner` IS NULL AND m.`owner` IS NOT NULL ;


INSERT INTO  `t_product_in_opt` (	`pid` ,	`msku`,	`owner`)
SELECT i.id,m.sku,m.`owner`
FROM t_product_info i
LEFT JOIN t_amazon_auth a ON a.id=i.amazonAuthId
LEFT JOIN t_product_in_opt o ON o.pid=i.id
LEFT JOIN db_erp.t_erp_material m ON m.sku=i.sku AND m.shopid=a.shop_id AND m.isdelete=0
WHERE o.pid IS NULL
AND m.id IS NOT NULL
AND m.owner IS NOT NULL	;

END;

