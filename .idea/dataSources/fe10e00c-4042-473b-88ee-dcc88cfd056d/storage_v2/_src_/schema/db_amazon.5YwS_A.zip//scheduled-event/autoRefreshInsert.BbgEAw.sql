create definer = root@`%` event autoRefreshInsert on schedule
    every '1' DAY
        starts '2024-06-14 16:46:08'
    on completion preserve
    enable
    do
    BEGIN

INSERT ignore into t_amz_product_refresh 
		SELECT i.id,i.amazonauthid,
		str_to_date('1949-10-01 00:00:00', '%Y-%m-%d %H:%i:%s'),
		str_to_date('1949-10-01 00:00:00', '%Y-%m-%d %H:%i:%s'),
		str_to_date('1949-10-01 00:00:00', '%Y-%m-%d %H:%i:%s'),
		i.sku,i.asin,i.marketplaceid,i.isparent,i.invalid
		FROM t_product_info i
		LEFT JOIN t_amz_product_refresh r ON r.pid=i.id
		LEFT JOIN t_amazon_auth a ON a.id=i.amazonauthid
		WHERE a.`disable`=0 
		AND i.invalid=0  
		AND a.createtime>DATE_SUB(CURRENT_DATE(), INTERVAL 1 DAY)
		AND r.pid IS NULL ;
END;

